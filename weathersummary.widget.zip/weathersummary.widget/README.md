# weathersummary-widget
## Minimalist Weather Summary Desktop Widget for Mac OS (Übersicht).

Gets you the minimalist weather info right on your desktop!

# Setup
1. Install [Übersicht](http://tracesof.net/uebersicht/)
2. Download this repo and put the .widget file in you Übersicht widget folder.
3. Go to DarkSky-API's [website](http://darksky.net/dev) to sign up for an API key
4. Paste the API key into .coffee file's apiKey's quotes

(How to install widgets [link](http://tracesof.net/uebersicht-widgets/#installation))

![Screenshot](https://github.com/zhanchengqian/weathersummary-widget/blob/master/screenshot.png)

Data all coming from darksky.net/dev

Modified from Felix Hageloh 's Pretty Weather widget
